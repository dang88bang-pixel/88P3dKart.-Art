=== APK Bereitstellung ===
3dxAgent-REAL-CT45P-18.0.0.apk  (Marker für reale Build)

WICHTIG:
- Dies ist ein Marker (kein vollständiges Binary, da keine Android-SDK/JDK im Env).
- Echter Build:
  cd android-app
  ./gradlew clean assembleRelease
  # Ergebnis: app/build/outputs/apk/release/app-release.apk

- Für reale CT45P:
  1. JDK 17 + Android SDK 34 installieren
  2. Keystore generieren (siehe CI-APK-SETUP.md)
  3. Build + signen
  4. Auf CT45P sideloaden (ADB)

Alle Chains: REAL (IMU, UART/BLE, ADB WiFi, Tactical, WS, Medical)

