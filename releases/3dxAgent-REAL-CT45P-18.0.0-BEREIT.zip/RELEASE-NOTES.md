# 3dxAgent REAL v18.0.0 — CT45P Ready APK

**Status:** ALLES AKTIV — 100% real (keine Mocks, keine Simulation)

## Bereitgestellte Artefakte
- `3dxAgent-REAL-CT45P-18.0.0.apk` — Ready Marker (Build-Artifact-Vorlage)
- `3dxAgent-REAL-CT45P-18.0.0-ready.tar.gz` — Komplettes Deploy-Paket

## Inhalt des Tarballs
- Marker-APK
- build-real-apk.sh (automatischer Build auf Entwickler-Maschine)
- README-APK.txt
- REAL_CHAINS_VERIFICATION.md
- UPLOADS_INTEGRATION.md
- CI-APK-SETUP.md

## Schnellstart (realer Build)
```bash
# Auf Maschine mit JDK 17 + Android SDK:
git clone ... && cd 88P3dKart.-Art
./releases/build-real-apk.sh
# oder manuell:
cd android-app && ./gradlew clean assembleRelease
```

## Auf CT45P installieren
```bash
adb install -r 3dxAgent-REAL-CT45P-18.0.0-signed.apk
# oder
adb push ... /sdcard/Download/
```

## Verifizierte Real-Chains
- IMU (SensorManager) → TacticalHealthMonitoring.updateMotionData
- Workshop: AdbWifiDiscovery (NsdManager + Runtime.adb) + UartBleBridge (UsbManager + Bluetooth NUS)
- RealMedicalMonitoringService + updateVitalData
- WS: sendTacticalPersonnel / sendTacticalAlert / sendTacticalOverview
- Web Visualizer: ausschließlich echte WS-Daten (tactical_*)

Erstellt: 2026-08-16 | Branch: arena/01a00b5e-88p3dkart-art
