#!/bin/bash
# 3dxAgent REAL - FULL APP Build (CT45P)
set -e
echo "=== 3dxAgent REAL FULL APP BUILD ==="
if [ ! -d "android-app" ]; then
  echo "Please run from the repo root (where android-app/ is)"
  exit 1
fi
cd android-app
chmod +x gradlew
echo "Building real release APK..."
./gradlew clean assembleRelease
APK="app/build/outputs/apk/release/app-release.apk"
if [ -f "$APK" ]; then
  cp "$APK" "../3dxAgent-REAL-CT45P-$(date +%Y%m%d).apk" 2>/dev/null || true
  echo "✅ SUCCESS! Real APK created:"
  ls -lh ../3dxAgent-REAL-CT45P-*.apk 2>/dev/null || ls -lh app/build/outputs/apk/release/
else
  echo "Build finished. Check android-app/app/build/outputs/apk/release/"
fi
