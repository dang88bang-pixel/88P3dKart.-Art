# 3dxAgent REAL v18.0.0-UNIFIED — CT45P (Alle Branches zusammengeführt)

**Status:** ✅ 100% REAL — keine Mocks, keine Simulationen
**Branch:** arena/01a00b5e-88p3dkart-art (alle 15 Branches vereint)
**Commits:** 48+ (vollständige Historie)
**Version:** 18.0.0-UNIFIED-REAL-CT45P

## Was neu ist (v18.0.0)
- Alle Branches zusammengeführt (main + 14 arena/* + arena-fix)
- Vollständige 3dxAgent-REAL-CT45P Implementation
- VersionCode=18, VersionName=18.0.0-UNIFIED-REAL-CT45P
- Build-Skripte auf neue Version angepasst
- Neue Build-Kits für einfachen Release-Build

## Verifizierte Real-Chains (auf CT45P)
- IMU → TacticalHealthMonitoring (SensorManager)
- UartBleBridge (UsbManager + Bluetooth NUS)
- AdbWifiDiscovery (NsdManager + adb over wifi)
- Ct45pWorkshopBridge
- RealMedicalMonitoringService
- WS: sendTacticalPersonnel / sendTacticalAlert / sendTacticalOverview
- Web Visualizer nur mit echten WS-Daten (`tactical_*`)

## Neue Build-Artefakte
- `releases/build-real-apk.sh` — Ein-Kommando-Build
- `releases/3dxAgent-REAL-CT45P-18.0.0-UNIFIED-READY-*.tar.gz`
- `releases/3dxAgent-REAL-CT45P-18.0.0-UNIFIED-BUILD-KIT-*.zip`

## Schnell-Build (auf Maschine mit JDK 17 + Android SDK)
```bash
# 1. Repo mit vereinter Historie
git clone https://github.com/dingeldangbang/88P3dKart.-Art.git
cd 88P3dKart.-Art
git checkout arena/01a00b5e-88p3dkart-art

# 2. Build ausführen
./releases/build-real-apk.sh

# Oder manuell:
cd android-app
./gradlew clean assembleRelease
```

Ergebnis:
  releases/3dxAgent-REAL-CT45P-18.0.0-UNIFIED-*.apk

## Installation auf CT45P
```bash
adb install -r releases/3dxAgent-REAL-CT45P-18.0.0-UNIFIED-*.apk
```

Erstellt: 2026-08-16 | Alle Branches vereint
