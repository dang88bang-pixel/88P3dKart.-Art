#!/bin/bash
# 3dxAgent REAL - LOS GO (one command to build real APK for CT45P)
set -e
echo "🚀 3dxAgent REAL LOS - GO!"
if [ ! -d android-app ]; then echo "Run from repo root"; exit 1; fi
cd android-app && chmod +x gradlew
./gradlew clean assembleRelease
cp app/build/outputs/apk/release/app-release.apk ../3dxAgent-REAL-CT45P-$(date +%Y%m%d).apk || true
echo "✅ Real APK ready!"
ls -lh ../3dxAgent-REAL-CT45P-*.apk 2>/dev/null || echo "Check android-app/app/build/outputs/apk/release/"
