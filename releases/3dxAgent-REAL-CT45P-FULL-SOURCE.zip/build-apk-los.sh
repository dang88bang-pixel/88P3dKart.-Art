#!/bin/bash
# 3dxAgent LOS - One-command REAL APK build for CT45P
set -e
echo "═══════════════════════════════════════════════════════════════"
echo "  3dxAgent REAL v18.0.0 - LOS BUILD (CT45P)"
echo "═══════════════════════════════════════════════════════════════"

if [ ! -d "android-app" ]; then
    echo "❌ Bitte im Repo-Root (88P3dKart.-Art) ausführen!"
    exit 1
fi

echo "→ Prüfe JDK..."
if ! command -v java &> /dev/null; then
    echo "❌ Kein Java gefunden. Installiere JDK 17:"
    echo "   sudo apt install openjdk-17-jdk   # oder temurin"
    exit 1
fi
java -version

echo "→ Wechsle in android-app..."
cd android-app
chmod +x gradlew

echo "→ Starte REAL Release Build..."
./gradlew clean assembleRelease --stacktrace

APK="app/build/outputs/apk/release/app-release.apk"
if [ -f "$APK" ]; then
    mkdir -p ../releases
    cp "$APK" "../releases/3dxAgent-REAL-CT45P-18.0.0-$(date +%Y%m%d).apk"
    echo "✅ ERFOLG! APK erstellt:"
    ls -lh ../releases/3dxAgent-REAL-CT45P-18.0.0-*.apk
    echo ""
    echo "Install on CT45P:"
    echo "  adb install ../releases/3dxAgent-REAL-CT45P-18.0.0-*.apk"
else
    echo "⚠️ Build beendet, aber APK nicht gefunden. Prüfe logs."
fi
