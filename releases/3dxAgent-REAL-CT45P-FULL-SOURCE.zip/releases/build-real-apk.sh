#!/bin/bash
# 3dxAgent REAL APK Build Script (für CT45P)
# Führe dieses auf einem System mit JDK 17 + Android SDK aus

set -e
echo "=== 3dxAgent REAL Build für CT45P ==="

if [ ! -d "android-app" ]; then
  echo "Bitte im Repo-Root ausführen (88P3dKart.-Art)"
  exit 1
fi

cd android-app

echo "1. Gradle Wrapper vorbereiten..."
chmod +x gradlew

echo "2. Clean + Release Build..."
./gradlew clean assembleRelease --stacktrace

APK_PATH="app/build/outputs/apk/release/app-release.apk"
if [ -f "$APK_PATH" ]; then
  cp "$APK_PATH" "../releases/3dxAgent-REAL-CT45P-18.0.0-signed.apk" || true
  echo "✅ APK erstellt: releases/3dxAgent-REAL-CT45P-18.0.0-signed.apk"
  ls -lh "../releases/3dxAgent-REAL-CT45P-18.0.0-signed.apk"
else
  echo "⚠️ APK nicht gefunden unter $APK_PATH"
  echo "Prüfe: ls app/build/outputs/apk/release/"
fi

echo "Fertig. Auf CT45P mit adb install ..."
